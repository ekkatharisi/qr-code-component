const p = document.getElementById("myID");
console.log(p.textContent);